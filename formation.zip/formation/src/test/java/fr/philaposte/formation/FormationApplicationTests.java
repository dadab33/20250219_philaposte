package fr.philaposte.formation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormationApplicationTests {

	@Test
	void contextLoads() {
	}

}
